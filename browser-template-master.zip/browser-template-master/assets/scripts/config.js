'use strict'

const config = {
  apiOrigins: {
    production: 'https://ga-wdi-boston.herokuapp.com'
  }
}

module.exports = config
